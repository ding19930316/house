<?php
define('AJ_MEMBER', true);
$moduleid = 4;
?>