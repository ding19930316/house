<?php
define('AJ_REWRITE', true);
$moduleid = 3;
require '../common.inc.php';
require AJ_ROOT.'/module/'.$module.'/announce.inc.php';
?>