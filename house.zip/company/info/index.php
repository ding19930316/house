<?php
define('AJ_REWRITE', true);
require '../config.inc.php';
require '../../common.inc.php';
$file = 'info';
require AJ_ROOT.'/module/'.$module.'/index.inc.php';
?>