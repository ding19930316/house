﻿<?php
defined('IN_AIJIACMS') or exit('Access Denied');
$edition = edition(1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=<?php echo AJ_CHARSET;?>"/>
<meta name="robots" content="noindex,nofollow"/>
<meta name="generator" content="AIJIACMS HOUSE - www.aijiacms.com"/>
<meta http-equiv="x-ua-compatible" content="IE=8"/>
<link rel="icon" href="favicon.ico" type="image/x-icon" />
<title>管理中心 - 水杉源码系统</title>
</head>
<frameset rows="96,*,4" frameborder="no" border="0" framespacing="0">
	<frame src="?action=top" noresize="noresize" id="topFrame" frameborder="0" 
name="topFrame" marginwidth="0" marginheight="0" scrolling="no">
	<frameset rows="*" cols="185,*" id="frame" framespacing="0" frameborder="no" border="0">
		<frame name="left" noresize scrolling="yes" src="?action=left">
		<frame name="main" noresize scrolling="yes" src="?action=main">
	</frameset>
	<frame src="admin/template/bottom.html" noresize="noresize" id="bottomFrame" frameborder="0" name="bottomFrame" marginwidth="0" marginheight="0" scrolling="no">
<noframes>
	<body>当前浏览器不支持框架!</body>
</noframes>
</frameset>
</html>
