<?php
defined('IN_AIJIACMS') or exit('Access Denied');
if(AJ_DEBUG) {
	echo '<br/><center class="f_gray px11">';
	debug();
	echo '</center><br/>';
}
?>
</body>
</html>