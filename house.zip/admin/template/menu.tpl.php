<?php
defined('IN_AIJIACMS') or exit('Access Denied');
?>
<div class="menu" onselectstart="return false" id="aijiacms_menu">
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td valign="bottom">
<table cellpadding="0" cellspacing="0">
<tr>
<td width="10">&nbsp;</td>
<?php echo $menu;?>
</tr>
</table>
</td>
<td width="110"><div></div></td>
</tr>
</table>
</div>