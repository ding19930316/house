// JavaScript Document
$(document).ready(function(){
		$(":text").addClass("inputtxt"); 
		$(":text").css({'background-image':'url(images/input.png)'});
		$(":password").addClass("inputtxt");
		$(":password").css({'background-image':'url(images/input.png)'});
	});