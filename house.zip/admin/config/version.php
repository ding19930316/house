<?php
define('MYAJ_NAME', 'AJ采集器');
define('MYAJ_VERSION', 'V1.3.120618');
define('MYAJ_QQ', '379486416');
?>