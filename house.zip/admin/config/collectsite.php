<?php
$Collectsite['7']['name'] = "爱房网成都";
$Collectsite['7']['config'] = "aifang";
$Collectsite['7']['url'] = "http://chengdu.aifang.com";
$Collectsite['7']['modid'] = "6";
$Collectsite['7']['verify_mode'] = "2";
$Collectsite['7']['spider_auth'] = "123456";
$Collectsite['7']['spider_ip'] = "";
$Collectsite['8']['name'] = "安居客";
$Collectsite['8']['config'] = "sale_anjuke";
$Collectsite['8']['url'] = "http://chengdu.anjuke.com";
$Collectsite['8']['modid'] = "5";
$Collectsite['8']['verify_mode'] = "2";
$Collectsite['8']['spider_auth'] = "123456";
$Collectsite['8']['spider_ip'] = "";
$Collectsite['10']['name'] = "安居客会员";
$Collectsite['10']['config'] = "anjumember";
$Collectsite['10']['url'] = "http://chengdu.anjuke.com";
$Collectsite['10']['modid'] = "2";
$Collectsite['10']['verify_mode'] = "2";
$Collectsite['10']['spider_auth'] = "123456";
$Collectsite['10']['spider_ip'] = "";
$Collectsite['13']['name'] = "好租测试";
$Collectsite['13']['config'] = "haozu_test";
$Collectsite['13']['url'] = "http://chengdu.haozu.com/";
$Collectsite['13']['modid'] = "7";
$Collectsite['13']['verify_mode'] = "2";
$Collectsite['13']['spider_auth'] = "123456";
$Collectsite['13']['spider_ip'] = "";
$Collectsite['15']['name'] = "安居客租房";
$Collectsite['15']['config'] = "anju_zufa";
$Collectsite['15']['url'] = "http://chengdu.anjuke.com";
$Collectsite['15']['modid'] = "7";
$Collectsite['15']['verify_mode'] = "2";
$Collectsite['15']['spider_auth'] = "123456";
$Collectsite['15']['spider_ip'] = "";

?>