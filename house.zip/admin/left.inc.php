<?php
	defined('IN_AIJIACMS') or exit('Access Denied');
	
   $menu=$_POST['menu'];

echo  $menu;
	include tpl('left_system');
?>