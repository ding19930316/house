<?php
require 'config.inc.php';
require '../common.inc.php';
require AJ_ROOT.'/module/'.$module.'/compare.inc.php';
?>