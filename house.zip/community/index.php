<?php
define('AJ_REWRITE', true);
require 'config.inc.php';
require '../common.inc.php';
// print_r($module);exit;
require AJ_ROOT.'/module/'.$module.'/index.inc.php';
?>
