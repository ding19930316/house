<?php
defined('IN_AIJIACMS') or exit('Access Denied');
#Your Functions
?>