<?php
$names = array (
  '51la' => '我要啦(www.51.la)',
  'cnzz' => '站长统计(www.cnzz.com)',
);
?>