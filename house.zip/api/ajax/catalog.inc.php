<?php
defined('IN_AIJIACMS') or exit('Access Denied');
isset($MODULE[$mid]) or exit;
include template('catalog', 'chip');
?>