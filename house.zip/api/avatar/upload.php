<?php
$_DPOST = $_POST;
include '../../common.inc.php';
$code = isset($code) ? trim($code) : '';
$_userid = intval(decrypt($code));
$_userid or exit('{"status":0}');
$user = $db->get_one("SELECT username FROM {$AJ_PRE}member WHERE userid=$_userid");
$user or exit('{"status":0}');
$pic1 = $_DPOST['pic1'];
$pic2 = $_DPOST['pic2'];
$pic3 = $_DPOST['pic3'];
$pic1 or exit('{"status":0}');
$pic2 or exit('{"status":0}');
$pic3 or exit('{"status":0}');
if(md5($pic3) == '68777643ca2d4cecce869c2d4cc9f4fd') exit('{"status":2}');
$md5 = md5($_userid);
$dir = AJ_ROOT.'/file/avatar/'.substr($md5, 0, 2).'/'.substr($md5, 2, 2).'/'.$_userid;
$img = array();
$img[1] = $dir.'.jpg';
$img[2] = $dir.'x48.jpg';
$img[3] = $dir.'x20.jpg';
file_put($img[1], base64_decode($pic1));
file_put($img[2], base64_decode($pic2));
file_put($img[3], base64_decode($pic3));
$s1 = getimagesize($img[1]);
$w1 = $s1[0];
$h1 = $s1[1];
$s2 = getimagesize($img[2]);
$w2 = $s2[0];
$h2 = $s2[1];
$s3 = getimagesize($img[3]);
$w3 = $s3[0];
$h3 = $s3[1];
if($s1 && $s2 && $s3 && $w1 == 128 && $h1 == 128 && $w2 == 48 && $h2 == 48 && $w3 == 20 && $h3 == 20) {
	$md5 = md5($user['username']);
	$dir = AJ_ROOT.'/file/avatar/'.substr($md5, 0, 2).'/'.substr($md5, 2, 2).'/_'.$user['username'];
	$img[4] = $dir.'.jpg';
	$img[5] = $dir.'x48.jpg';
	$img[6] = $dir.'x20.jpg';
	file_put($img[4], base64_decode($pic1));
	file_put($img[5], base64_decode($pic2));
	file_put($img[6], base64_decode($pic3));
	if($AJ['ftp_remote'] && $AJ['remote_url']) {
		require AJ_ROOT.'/include/ftp.class.php';
		$ftp = new dftp($AJ['ftp_host'], $AJ['ftp_user'], $AJ['ftp_pass'], $AJ['ftp_port'], $AJ['ftp_path'], $AJ['ftp_pasv'], $AJ['ftp_ssl']);
		if($ftp->connected) {
			foreach($img as $i) {
				$t = explode("/file/", $i);
				$ftp->dftp_put('file/'.$t[1], $t[1]);
			}
		}
	}
	echo '{"status":1}';
} else {
	file_del($img[1]);
	file_del($img[2]);
	file_del($img[3]);
	exit('{"status":3}');
}
?>