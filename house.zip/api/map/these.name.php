<?php
$names = array (
  'baidu' => '百度地图(baidu)',
  'qq' => '腾讯地图(qq)',
  '51ditu' => '灵图地图(51ditu)',
  'mapabc' => '高德地图(mapabc)',
  'google' => '谷歌地图(google)',
);
?>