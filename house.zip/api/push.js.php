<?php
require '../common.inc.php';
header("Content-type:text/javascript");	
include template('push', 'chip');
?>